

In order to run the program -

Operation 
------------
 
first option:
---------------
1. Select the folder routing by clicking on the relevant browse button.
2. Select the routing where the posting files will be saved by clicking on the relevant browse button.
3. Checkbox should indicate whether to run with stemming procedure or not.
4. Press the Start button.


After the run the posting is created:
------------------------------------------
On the screen, you will see a message containing the relevant details about the run:
the total run time of the process in sec, the number of documents that Indexed, the number of terms in the corpus.

There is the option to save the dictionary by selecting the routing where the objects will be stored and then clicking the load dictionary button. 
Do not press this button before entering the path.

There is the option to load a dictionary file ready for the program.
To do this, select the routing of the posting files and then click the Load Dictionary button and select the folder routing in which the objects are stored.
The dictionary can be viewed by clicking on the relevant buttons even after loading.

There is the option to choose if the the program run includes a stemming procedure or not

There is the option to view the dictionary via notepad by clicking the show Dictionary button.

There is the option to delete the program memory and all created files by pressing the reset button.


Second option:
-------------
1. Select the routing where the posting files will be saved by clicking on the relevant browse button.
2. Checkbox should indicate whether to run with stemming procedure or not.
3. Checkbox should indicate whether to run with semantic treatment procedure or not.
4. Press the Load dictionary button.

After the run the posting filse that was in the path, are loaded to the program memory
--------------------------------------------------------------------------------------
In the "search" text fild you can write a query and run it with clicking on the Run butten.
We will look for the 50 relevant documents for the query.

where the "choose query file" label you can click on the browse butten and then choose a file of queries,
after choosing a file, click on the Go button. That would do the same as the Run button,
only now for all queries written in the file.

You can select a path to which the results will be saved. 
In the browse button, next to the "save" label you can select the path of the save.

____________________________________________________________________________________________________________
This will pop up a window and there will be a list of all queries if there is more than one.
Now for whichever document we choose from the list of documents we can see the list of dominant entities.

**how it gose**
1. choose a query number from the list.
2. click on the button "choose query".
3. select a docId from the list.
4. click on the button "identify entities".
_____________________________________________________________________________________________________________


---------------
Enjoy your use

by Doron and Michal